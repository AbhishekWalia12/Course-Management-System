package com.cms.exception;

public class AdmissionInvalidException extends Exception {
	
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public AdmissionInvalidException(String message) {
	super(message);
}

public AdmissionInvalidException() {
	
}

}
