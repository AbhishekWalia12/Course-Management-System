package com.cms.exception;

public class AssociateInvalidException extends Exception {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6092885688115118693L;

	public AssociateInvalidException(String message)
	{
		super(message);
	}
}
