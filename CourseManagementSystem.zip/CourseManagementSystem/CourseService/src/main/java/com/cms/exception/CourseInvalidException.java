package com.cms.exception;

public class CourseInvalidException  extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CourseInvalidException(String message) {
		
		super(message);
		
	}

}
